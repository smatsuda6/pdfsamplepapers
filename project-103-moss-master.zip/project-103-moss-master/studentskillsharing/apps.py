from django.apps import AppConfig


class StudentskillsharingConfig(AppConfig):
    name = 'studentskillsharing'
